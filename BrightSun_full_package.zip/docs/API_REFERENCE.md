# API Reference
core.preprocessing.preprocess_frame(frame, config) -> frame
