# دليل المطور — Bright Sun
- بنية تطبيق PyQt5
- وحدات preprocessing قابلة للتمديد
- سكربت Windows EXE: `scripts\build_windows_exe.bat`
