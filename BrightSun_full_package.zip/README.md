# Bright Sun — المنصة الذكية للمراقبة والتعرف على الوجوه
![Logo](app/ui/assets/logo.png)

- Arabic/English UI
- Low‑light, deblur, super‑resolution, undistort
- Hooks for RetinaFace/ArcFace (optional)
- Windows EXE build script via PyInstaller

## Build EXE (Windows)
Run: `scripts\build_windows_exe.bat`
