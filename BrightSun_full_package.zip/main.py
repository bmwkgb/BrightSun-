#!/usr/bin/env python3
import sys, logging
from PyQt5.QtWidgets import QApplication
from app.main_window import MainWindow

logging.basicConfig(level=logging.INFO)
def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Bright Sun")
    app.setApplicationVersion("1.0.0")
    win = MainWindow(lang='ar')
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
