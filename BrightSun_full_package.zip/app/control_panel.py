from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QComboBox, QGroupBox, QFormLayout, QPushButton
from PyQt5.QtCore import pyqtSignal

class ControlPanel(QWidget):
    languageChanged = pyqtSignal(str)
    def __init__(self, tr):
        super().__init__()
        self.tr = tr
        self._lang = 'ar'
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        lang_group = QGroupBox(self.tr('language'))
        form = QFormLayout()
        self.lang_combo = QComboBox()
        self.lang_combo.addItem(self.tr('arabic'), 'ar')
        self.lang_combo.addItem(self.tr('english'), 'en')
        self.lang_combo.currentIndexChanged.connect(self._on_lang_change)
        form.addRow(QLabel(self.tr('language')), self.lang_combo)
        lang_group.setLayout(form)
        apply_btn = QPushButton(self.tr('start'))
        layout.addWidget(lang_group)
        layout.addWidget(apply_btn)
        layout.addStretch(1)

    def _on_lang_change(self, idx):
        code = self.lang_combo.itemData(idx)
        self.languageChanged.emit(code)
