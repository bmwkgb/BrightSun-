from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QPushButton, QSizePolicy
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QImage, QPixmap
import numpy as np, cv2, random

class CameraWidget(QWidget):
    def __init__(self, camera_name, camera_id):
        super().__init__()
        self.camera_name = camera_name
        self.camera_id = camera_id
        self.is_active = False
        self.setMinimumSize(320, 240)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        layout = QVBoxLayout(self)
        self.title_label = QLabel(self.camera_name)
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setStyleSheet("background-color: rgba(255,185,0,0.15); color: #ffd369; padding: 6px;")

        self.video_label = QLabel()
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet("background-color: #000; border: 1px solid #24324a;")
        self.video_label.setMinimumSize(320, 240)

        control = QHBoxLayout()
        self.status_btn = QPushButton("▶")
        self.status_btn.clicked.connect(self.toggle)
        control.addWidget(self.status_btn)
        control.addStretch(1)

        layout.addWidget(self.title_label)
        layout.addWidget(self.video_label)
        layout.addLayout(control)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)

        self._default_frame = np.ones((240,320,3), np.uint8)*15
        cv2.putText(self._default_frame, self.camera_name, (40, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
        self._show(self._default_frame)

    def toggle(self):
        self.is_active = not self.is_active
        if self.is_active:
            self.timer.start(33)
            self.status_btn.setText("⏸")
        else:
            self.timer.stop()
            self.status_btn.setText("▶")
            self._show(self._default_frame)

    def _tick(self):
        import random
        frame = np.ones((240,320,3), np.uint8)*10
        for _ in range(random.randint(1,5)):
            x,y = random.randint(0,300), random.randint(0,220)
            r = random.randint(6,20)
            color = (random.randint(50,255), random.randint(50,255), random.randint(50,255))
            cv2.circle(frame, (x,y), r, color, -1)
        cv2.putText(frame, self.camera_name, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 1)
        self._show(frame)

    def _show(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h,w,ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch*w, QImage.Format_RGB888)
        pix = QPixmap.fromImage(qimg)
        self.video_label.setPixmap(pix.scaled(self.video_label.width(), self.video_label.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
