import json, os
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QCheckBox, QGridLayout, QMessageBox, QToolBar, QAction, QSizePolicy)
from PyQt5.QtCore import Qt, QDateTime, QTimer, QSize
from PyQt5.QtGui import QPixmap
from app.camera_widget import CameraWidget
from app.control_panel import ControlPanel
from app.styles import apply_style

def load_locale(code):
    p = os.path.join(os.path.dirname(__file__), 'i18n', f'{code}.json')
    with open(p, 'r', encoding='utf-8') as f:
        return json.load(f)

class MainWindow(QMainWindow):
    def __init__(self, lang='ar'):
        super().__init__()
        self.lang = lang
        self.locale = load_locale(lang)
        self.setWindowTitle(self.tr('app_title'))
        self.setGeometry(80, 40, 1400, 820)

        apply_style(self)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)

        self.display_widget = QWidget()
        self.display_layout = QVBoxLayout(self.display_widget)

        self.control_panel = ControlPanel(self.tr)
        self.control_panel.languageChanged.connect(self._switch_lang)

        main_layout.addWidget(self.display_widget, 70)
        main_layout.addWidget(self.control_panel, 30)

        self._build_menu()
        self._build_toolbar()
        self._build_display()

        self.status_label = QLabel(self.tr('status_ready'))
        self.statusBar().addWidget(self.status_label)
        self.cameras_label = QLabel(f"{self.tr('status_cameras')}: 0/4")
        self.statusBar().addPermanentWidget(self.cameras_label)
        self.faces_label = QLabel(f"{self.tr('status_faces')}: 0")
        self.statusBar().addPermanentWidget(self.faces_label)

        self.time_label = QLabel()
        self.statusBar().addPermanentWidget(self.time_label)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(1000)

    def tr(self, key):
        return self.locale.get(key, key)

    def _switch_lang(self, code):
        self.lang = code
        self.locale = load_locale(code)
        self.setWindowTitle(self.tr('app_title'))

    def _build_menu(self):
        menubar = self.menuBar()
        menubar.addMenu(self.tr('menu_file'))
        menubar.addMenu(self.tr('menu_cameras'))
        menubar.addMenu(self.tr('menu_recognition'))
        menubar.addMenu(self.tr('menu_view'))
        menubar.addMenu(self.tr('menu_help'))

    def _build_toolbar(self):
        tb = QToolBar("Main")
        tb.setIconSize(QSize(28, 28))
        self.addToolBar(tb)

        start = QAction(self.tr('start'), self)
        pause = QAction(self.tr('pause'), self)
        stop = QAction(self.tr('stop'), self)
        settings = QAction(self.tr('settings'), self)

        tb.addAction(start); tb.addAction(pause); tb.addAction(stop); tb.addSeparator(); tb.addAction(settings)

        logo_p = os.path.join(os.path.dirname(__file__), 'ui', 'assets', 'logo.png')
        if os.path.exists(logo_p):
            lbl = QLabel()
            lbl.setPixmap(QPixmap(logo_p).scaledToHeight(26, Qt.SmoothTransformation))
            lbl.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            tb.addWidget(lbl)

    def _build_display(self):
        top = QWidget()
        hl = QHBoxLayout(top)
        self.view_mode = QComboBox(); self.view_mode.addItems([self.tr('view_live'), self.tr('view_analytics'), self.tr('view_archive')])
        self.grid = QComboBox(); self.grid.addItems([self.tr('grid_2x2'), self.tr('grid_3x3'), self.tr('grid_4x4')])
        self.auto_cycle = QCheckBox(self.tr('auto_cycle'))
        hl.addWidget(self.view_mode); hl.addWidget(self.grid); hl.addWidget(self.auto_cycle); hl.addStretch(1)

        self.grid_widget = QWidget()
        self.grid_layout = QGridLayout(self.grid_widget)

        self.display_layout.addWidget(top)
        self.display_layout.addWidget(self.grid_widget)

        names = ["Entrance A", "Parking", "Lobby", "Backyard"]
        for i, n in enumerate(names):
            w = CameraWidget(n, i)
            self.grid_layout.addWidget(w, i//2, i%2)

    def _tick(self):
        now = QDateTime.currentDateTime().toString('yyyy-MM-dd hh:mm:ss')
        self.time_label.setText(now)

    def closeEvent(self, e):
        reply = QMessageBox.question(self, 'Confirm', self.tr('confirm_exit'), QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            e.accept()
        else:
            e.ignore()
