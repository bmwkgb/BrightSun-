from PyQt5.QtGui import QFont
def apply_style(widget):
    arabic_font = QFont("Segoe UI", 10)
    widget.setFont(arabic_font)
    style = '''
    QMainWindow { background-color: #0b1220; }
    QLabel { color: #f5f7fa; }
    QPushButton { background-color: #f5a623; color: #0b1220; border: none; padding: 8px 14px; border-radius: 6px; }
    QPushButton:hover { background-color: #ffc04d; }
    QPushButton:pressed { background-color: #d7941d; }
    QComboBox { padding: 6px; border: 1px solid #24324a; border-radius: 6px; background-color: #0f1a33; color: #e2e8f0; }
    QGroupBox { font-weight: bold; border: 1px solid #24324a; border-radius: 8px; margin-top: 10px; padding-top: 14px; color: #e2e8f0; }
    QTabWidget::pane { border: 1px solid #24324a; border-radius: 6px; background-color: #0f1a33; }
    QTabBar::tab { background-color: #0f1a33; color: #a0aec0; padding: 8px 16px; border-top-left-radius: 6px; border-top-right-radius: 6px; }
    QTabBar::tab:selected { background-color: #1a2540; color: #f5f7fa; }
    '''
    widget.setStyleSheet(style)
