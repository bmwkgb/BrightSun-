import cv2
def undistort(img, camera_matrix=None, dist_coeffs=None):
    if camera_matrix is None or dist_coeffs is None:
        return img
    return cv2.undistort(img, camera_matrix, dist_coeffs, None, camera_matrix)
