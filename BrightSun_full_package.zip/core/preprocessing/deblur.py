import cv2, numpy as np
def wiener_deblur(img, ksize=3, K=0.01):
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    psf = np.ones((ksize, ksize)) / (ksize*ksize)
    img_f = np.fft.fft2(img_gray)
    psf_f = np.fft.fft2(psf, s=img_gray.shape)
    psf_f_conj = np.conj(psf_f)
    wiener = (psf_f_conj / (psf_f * psf_f_conj + K)) * img_f
    res = np.abs(np.fft.ifft2(wiener))
    res = cv2.normalize(res, None, 0, 255, cv2.NORM_MINMAX).astype("uint8")
    return cv2.cvtColor(res, cv2.COLOR_GRAY2BGR)
