from .enhance import enhance_low_light, apply_clahe
from .deblur import wiener_deblur
from .distortion import undistort
from .sr import super_resolve

def preprocess_frame(frame, config=None):
    if config is None:
        config = {}
    if config.get('undistort'):
        frame = undistort(frame, config.get('camera_matrix'), config.get('dist_coeffs'))
    if config.get('low_light'):
        frame = enhance_low_light(frame)
        frame = apply_clahe(frame)
    if config.get('deblur'):
        frame = wiener_deblur(frame)
    if config.get('super_resolution'):
        frame = super_resolve(frame)
    return frame
